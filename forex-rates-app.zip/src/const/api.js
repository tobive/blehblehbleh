export const API_URL = 'https://api.exchangeratesapi.io/latest?base=USD';
